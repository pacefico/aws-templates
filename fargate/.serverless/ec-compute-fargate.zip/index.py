from main import execute


if __name__ == '__main__':
    name = 'fargate'
    execute(name)
    
    return "success!"